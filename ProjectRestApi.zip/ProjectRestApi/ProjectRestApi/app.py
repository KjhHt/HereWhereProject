from flask import Flask
from flask_restful import Api
from flask_cors import CORS
from api.google_hotel_crawling_api import Hotel_Crawling
from api.google_hotel_api import Hotel
from api.google_restaurant_api import Restaurant
from api.google_landmark_api import Landmark
from api.SearchImage import SearchImage

app = Flask(__name__)
api = Api(app)
CORS(app)

api.add_resource(SearchImage,'/searchImage')
api.add_resource(Hotel,'/hotel')
api.add_resource(Hotel_Crawling,'/hotel_crawling')
api.add_resource(Restaurant,'/restaurant')
api.add_resource(Landmark,'/landmark')

if __name__ == '__main__':
    app.run(debug=True)