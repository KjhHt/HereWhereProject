from flask_restful import Resource
from model.google_landmark import find_nearby_places

class Landmark(Resource):
    def get(self):
        api_key = 'AIzaSyBMpSPfY-brXtLzGQNDvnsJyf-r61u-H6k'
        location = '37.5006113,127.1010022'  # 위례 경도
        info = find_nearby_places(api_key, location, radius=3000, keyword='landmark', max_results=15)

        return info