<template>
    <DMForm></DMForm>
</template>

<script setup>
  import DMForm from '@/components/dm/DMForm.vue'
</script>

<style scoped>

</style>