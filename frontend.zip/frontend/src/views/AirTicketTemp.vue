<template>
    <FlightList></FlightList>
</template>
<script setup>
import FlightList from '@/components/main/flight/FlightList'
</script>
<style>
    
</style>