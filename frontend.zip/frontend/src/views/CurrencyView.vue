<template>
    <div>
        <CurrencyLayout/>
    </div>
</template>
<script setup>
import CurrencyLayout from '@/components/main/currency/CurrencyLayout.vue';
</script>
<style>
    
</style>