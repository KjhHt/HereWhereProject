<template>
    <h2 class="Title-sc-1sm6d0j-2 fmnYkt burited_point">트립 모먼트</h2>
</template>
<style scope>
    .Title-sc-1sm6d0j-2 {
    margin-top: 40px;
    padding: 24px 32px;
    font-size: 28px;
    color: rgb(15, 41, 77);
    line-height: 34px;
    text-align: center;
}
</style>